TPM carousel: A new cinematic glow tool is coming to Lightroom – and no, it’s not GenAI. These are the 4 biggest updates to Adobe Lightroom 2027

Slides: 5, 1080 x 1440, in posting order (01 is the cover).
Captions: one text file per account. TPM Facebook and TPM Instagram use the "we" caption,
David Molnar Facebook uses David's first person caption.
sources.txt: the official pages every fact and image comes from.

Status when this zip was made: Waiting for David.
Nothing is posted automatically. Post by hand in Meta Business Suite, and only after David approves.
David's personal Instagram is never used.
