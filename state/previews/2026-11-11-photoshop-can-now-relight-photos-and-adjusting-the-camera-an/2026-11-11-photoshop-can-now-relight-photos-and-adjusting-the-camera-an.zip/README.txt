TPM carousel: Photoshop can now relight photos – and adjusting the camera angle is coming next. These are the 6 biggest updates in Photoshop 2027

Slides: 5, 1080 x 1440, in posting order (01 is the cover).
Captions: one text file per account. TPM Facebook and TPM Instagram use the "we" caption,
David Molnar Facebook uses David's first person caption.
sources.txt: the official pages every fact and image comes from.

Status when this zip was made: Waiting for David.
Nothing is posted automatically. Post by hand in Meta Business Suite, and only after David approves.
David's personal Instagram is never used.
